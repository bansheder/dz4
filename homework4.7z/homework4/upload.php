<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $filename = preg_replace('/[^a-zA-Z0-9_-]/', '', $_POST['filename']); 
    $newWidth = (int)$_POST['width'];
    $uploadedFile = $_FILES['file'];
    if ($uploadedFile['error'] !== UPLOAD_ERR_OK) {
        die("Ошибка загрузки файла!");
    }
    $fileExtension = strtolower(pathinfo($uploadedFile['name'], PATHINFO_EXTENSION)); 
    if ($fileExtension !== 'jpg' && $fileExtension !== 'jpeg') {
        die("Допускаются только JPG-файлы!");
    }

    $tmpPath = $uploadedFile['tmp_name'];
    $outputPath = __DIR__ . '/uploads/' . $filename . '.jpg';
    if (!is_dir(__DIR__ . '/uploads')) {
        mkdir(__DIR__ . '/uploads', 0755, true);
    }
    list($originalWidth, $originalHeight) = getimagesize($tmpPath); 
    $newHeight = ($originalHeight / $originalWidth) * $newWidth;

    $srcImage = imagecreatefromjpeg($tmpPath); 
    $resizedImage = imagecreatetruecolor($newWidth, $newHeight); 

    imagecopyresampled($resizedImage, $srcImage, 0, 0, 0, 0, $newWidth, $newHeight, $originalWidth, $originalHeight);
    if (imagejpeg($resizedImage, $outputPath, 90)) {
        echo "Файл успешно загружен и сохранен как $outputPath";
    } else {
        echo "Ошибка сохранения файла.";
    }
    imagedestroy($srcImage);
    imagedestroy($resizedImage);
}
